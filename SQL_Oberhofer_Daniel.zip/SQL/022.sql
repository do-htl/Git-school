select first_name from employees where first_name like '%c%' and first_name like '%b%';
