select department_id, SUM(salary) from employees group by department_id;
