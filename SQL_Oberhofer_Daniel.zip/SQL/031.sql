select MAX(salary)-MIN(salary) from employees;
